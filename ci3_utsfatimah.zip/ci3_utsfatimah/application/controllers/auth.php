<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

    public function __construct(){
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->helper('url');
        $this->load->model('Auth_model');
    }

    public function index(){
        $this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email');// Menetapkan aturan validasi untuk field 'email'
        $this->form_validation->set_rules('password', 'Password', 'required|trim');// Menetapkan aturan validasi untuk field 'password'

        // Mengecek apakah validasi berhasil
        if($this->form_validation->run() == false){
            $this->load->view('Auth/login'); // Jika validasi gagal, tampilkan halaman login
        }else{
            $this->login();// Jika validasi berhasil, lanjutkan ke proses login
        } 
    }

    public function login() {
        // Ambil email dan password dari form
        $email = $this->input->post('email');
        $password = $this->input->post('password');
    
        // Gunakan model untuk mencari data pengguna berdasarkan email
        $masuk = $this->Auth_model->get_user_by_email($email);
    
        if ($masuk) {  // Jika pengguna ditemukan
            if ($password === $masuk['password']) {  // Verifikasi password
                $data_masuk = [  // Set data login ke session
                    'email' => $masuk['email'],
                    'id_role' => $masuk['id_role']
                ];
                $this->session->set_userdata($data_masuk);  // Set session data
    
                // Redirect berdasarkan role pengguna
                if ($masuk['id_role'] == 1) {
                    redirect('Produktv');  // Redirect ke halaman admin
                } else {
                    redirect('User');  // Redirect ke halaman user
                }
            } else {
                // Set flash message untuk password salah
                $this->session->set_flashdata('message_password', '<small><div class="alert alert-danger" role="alert">Password salah!</div></small>');
                redirect('Auth');  // Redirect ke halaman login
            }
        } else {
            // Set flash message untuk email yang tidak ditemukan
            $this->session->set_flashdata('message_email', '<small><div class="alert alert-danger" role="alert">Email tidak terdaftar!</div></small>');
            redirect('Auth');  // Redirect ke halaman login
        }
    }
    

    public function regis(){
        $this->form_validation->set_rules('user', 'User', 'required|trim');// Aturan validasi untuk field 'user' (username)        
        $this->form_validation->set_rules('status', 'Status', 'required|trim');// Aturan validasi untuk field 'status'         
        // Aturan validasi untuk email dengan pengecekan apakah sudah terdaftar
        $this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email|is_unique[tbl_userr.email]', [
            'is_unique' => 'Email yang anda masukkan sudah terdaftar'
        ]);
        // Aturan validasi untuk field 'password'
        $this->form_validation->set_rules('password', 'Password', 'required|trim|min_length[3]', [
            'min_length' => 'Password terlalu pendek!'
        ]);
    
        // Mengecek apakah validasi form berhasil
        if($this->form_validation->run() == false){
            // Jika validasi gagal, kembali ke form registrasi
            $this->load->view('auth/regis');
        } else {
            // Jika validasi berhasil, proses data yang dimasukkan
            $masuk = [
                'id_user' => $this->Auth_model->generate_user_id(), // Menghasilkan ID baru dengan format USR001
                'user' => htmlspecialchars($this->input->post('user')),
                'status' => htmlspecialchars($this->input->post('status')),
                'email' => htmlspecialchars($this->input->post('email')),
                // Mengenkripsi password sebelum disimpan
                'password' => ($this->input->post('password')),
                'id_role' => 2,
                'tanggal_daftar' => time()
            ];
    
            // Panggil model untuk menyimpan data registrasi
            if($this->Auth_model->registrasi($masuk)){
                // Jika berhasil, redirect ke halaman login
                redirect('Auth');
            } else {
                // Jika gagal, beri pesan kesalahan
                $this->session->set_flashdata('message_regis', '<small><div class="alert alert-danger" role="alert">Registrasi gagal, harap coba lagi!</div></small>');
                redirect('auth/regis');
            }
        }
    }
    
    // Lupa Password
    public function forgot_password() {
        $this->load->view('auth/lupa_pw');
    }

    public function process_forgot_password() {
        $email = $this->input->post('email');
        $user = $this->Auth_model->get_user_by_email($email);

        if ($user) {
            $this->session->set_flashdata('message_pw', 'Password Anda: ' . $user['password']);
            redirect('Auth');
        } else {
            $this->session->set_flashdata('error', 'Maaf, email tidak terdaftar.');
            redirect('Auth/forgot_password');
        }
    }

    public function logout(){
        // Menghapus semua data sesi pengguna
        $this->session->sess_destroy();
        
        // Mengarahkan pengguna kembali ke halaman login
        redirect('Auth');
    }

    public function manage_users() {
        // Ambil semua data pengguna dari model
        $users = $this->Auth_model->get_all_users();
    
        // Format ID pengguna menjadi 'USR001', 'USR002', dst.
        foreach ($users as &$user) {
            $user['id_user'] = 'USR' . sprintf('%03d', $user['id_user']);
        }
    
        // Kirim data ke view 'daftar_user'
        $data['users'] = $users;
        $this->load->view('admin/data_user', $data);
    }
    
}
?>