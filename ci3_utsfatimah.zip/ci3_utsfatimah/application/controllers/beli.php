<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Beli extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Beli_model');
        $this->load->model('Produktv_model');
    }

    public function index()
    {
        $data['beli'] = $this->Beli_model->get_all_beli();
    $data['produk'] = $this->Produktv_model->get_all_produk_tv(); // Mengambil data produk
    $this->load->view('user/beli_produktv', $data); // Memastikan view yang benar dimua
    }

    public function tambah()
    {
        // Memanggil metode yang benar di model Produktv_model
        $data['produk'] = $this->Produktv_model->get_all_produk_tv();  // Mengambil data produk TV
        
        if ($this->input->post()) {
            $nama = $this->input->post('nama');
            $jumlah = $this->input->post('jumlah');
            $alamat = $this->input->post('alamat');
            $id_tv = $this->input->post('id_tv');
            $harga = $this->Produktv_model->get_harga_by_id($id_tv);  // Jika Anda ingin ambil harga berdasarkan ID produk
    
            $total = $harga * $jumlah;
    
            $beli_data = array(
                'nama' => $nama,
                'jumlah' => $jumlah,
                'alamat' => $alamat,
                'total' => $total,
                'id_tv' => $id_tv
            );
    
            $this->Beli_model->insert_beli($beli_data);
            $this->session->set_flashdata('success', 'Transaksi anda berhasil');
            redirect('User');
        }
    
        $this->load->view('user/home', $data); // Pastikan untuk memanggil view yang benar
    }
    
    public function transaksi_admin()
{
    // Mengambil data transaksi
    $data['beli'] = $this->Beli_model->get_all_beli();  // Change 'transaksi' to 'beli'

    // Memanggil view untuk admin
    $this->load->view('admin/transaksi', $data);
}


    

    public function hapus($id)
    {
        $this->Beli_model->delete_beli($id);
        $this->session->set_flashdata('success', 'Transaksi berhasil dihapus!');
        redirect('Beli/transaksi_admin');
    }
}
