<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Produktv extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Produktv_model');
        $this->load->helper('url');
        $this->load->library('form_validation');
        $this->load->library('upload');  // Memastikan upload library dimuat dengan benar
    }

    // Halaman utama menampilkan semua produk TV
    public function index() {
        $data['produktv'] = $this->Produktv_model->get_all_produk_tv();
        $this->load->view('admin/produktv', $data);
    }

    public function tambah() {
        $this->form_validation->set_rules('merek', 'Merek', 'required');
        $this->form_validation->set_rules('ukuran_layar', 'Ukuran Layar', 'required');
        $this->form_validation->set_rules('resolusi', 'Resolusi', 'required');
        $this->form_validation->set_rules('tipe_layar', 'Tipe Layar', 'required');
        $this->form_validation->set_rules('harga', 'Harga', 'required');
        $this->form_validation->set_rules('stok', 'Stok', 'required');
    
        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', 'Gagal menambahkan produk. Silakan periksa kembali input Anda!');
            $this->load->view('admin/tambah_produk');
        } else {
            $data = [
                'merek' => $this->input->post('merek'),
                'ukuran_layar' => $this->input->post('ukuran_layar'),
                'resolusi' => $this->input->post('resolusi'),
                'tipe_layar' => $this->input->post('tipe_layar'),
                'harga' => $this->input->post('harga'),
                'stok' => $this->input->post('stok')
            ];
    
            if ($this->Produktv_model->tambah_produk_tv($data)) {
                $this->session->set_flashdata('success', 'Produk berhasil ditambahkan!');
            } else {
                $this->session->set_flashdata('error', 'Terjadi kesalahan saat menambahkan produk. Coba lagi nanti!');
            }
            redirect('ProdukTV');
        }
    }
    
    public function edit($id_tv) {
        $data['tv'] = $this->Produktv_model->get_produk_tv_by_id($id_tv); // Pastikan nama key sesuai
    
        if (!$data['tv']) {
            // Jika produk tidak ditemukan, arahkan kembali dengan pesan error
            $this->session->set_flashdata('error', 'Produk tidak ditemukan!');
            redirect('Produktv');
        }
    
        $this->form_validation->set_rules('merek', 'Merek', 'required');
        $this->form_validation->set_rules('ukuran_layar', 'Ukuran Layar', 'required');
        $this->form_validation->set_rules('resolusi', 'Resolusi', 'required');
        $this->form_validation->set_rules('tipe_layar', 'Tipe Layar', 'required');
        $this->form_validation->set_rules('harga', 'Harga', 'required');
        $this->form_validation->set_rules('stok', 'Stok', 'required');
    
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('admin/edit_produktv', $data); // Kirim data 'tv'
        } else {
            $update_data = [
                'merek' => $this->input->post('merek'),
                'ukuran_layar' => $this->input->post('ukuran_layar'),
                'resolusi' => $this->input->post('resolusi'),
                'tipe_layar' => $this->input->post('tipe_layar'),
                'harga' => $this->input->post('harga'),
                'stok' => $this->input->post('stok'),
            ];
    
            if ($this->Produktv_model->update_produk_tv($id_tv, $update_data)) {
                $this->session->set_flashdata('success', 'Produk berhasil diupdate!');
            } else {
                $this->session->set_flashdata('error', 'Terjadi kesalahan saat mengupdate produk. Coba lagi nanti!');
            }
            redirect('Produktv');
        }
    }
    
    
    public function hapus($id) {
        if ($this->Produktv_model->hapus_produk_tv($id)) {
            $this->session->set_flashdata('success', 'Produk berhasil dihapus!');
        } else {
            $this->session->set_flashdata('error', 'Terjadi kesalahan saat menghapus produk. Coba lagi nanti!');
        }
        redirect('ProdukTV');
    }
    
}
