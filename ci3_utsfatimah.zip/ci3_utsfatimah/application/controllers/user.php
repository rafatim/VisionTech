<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('Produktv_model');
    }

    public function index() {
        // Fetch all products using the correct method name
        $data['produk_tv'] = $this->Produktv_model->get_all_produk_tv();

        // Load the view and pass the data
        $this->load->view('user/home', $data);
    }
}
