<?php
class Auth_model extends CI_Model {

public function __construct(){
    parent::__construct();
    $this->load->database(); // Memuat database
}

// Fungsi untuk registrasi pengguna baru
public function registrasi($data){
    // Menyimpan data pengguna baru ke dalam tabel tbl_user
    return $this->db->insert('tbl_userr', $data); 
}

// Fungsi untuk mendapatkan pengguna berdasarkan email
public function get_user_by_email($email){
    return $this->db->get_where('tbl_userr', ['email' => $email])->row_array();
}

// Fungsi untuk mendapatkan ID pengguna terakhir dan membuat ID baru
public function generate_user_id() {
    $this->db->select('MAX(id_user) as last_id');
    $query = $this->db->get('tbl_userr');
    $result = $query->row_array();
    $last_id = $result['last_id'];
    
    if ($last_id) {
        // Ambil angka dari ID terakhir dan tambahkan 1
        $last_number = (int)substr($last_id, 3); // Mengambil bagian angka setelah "USR"
        $new_number = $last_number + 1;
    } else {
        // Jika belum ada ID sebelumnya, mulai dengan 1
        $new_number = 1;
    }
    
    // Format ID baru dengan angka 3 digit, contoh: USR001
    return 'USR' . str_pad($new_number, 3, '0', STR_PAD_LEFT);
}

public function get_all_users() {
    return $this->db->get('tbl_userr')->result_array();
}
}
?>