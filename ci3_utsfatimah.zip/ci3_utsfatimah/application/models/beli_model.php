<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Beli_model extends CI_Model {

    private $table = 'beli';

    public function get_all_beli()
    {
        $this->db->select('beli.*, tbl_produk_tv.merek');
        $this->db->join('tbl_produk_tv', 'beli.id_tv = tbl_produk_tv.id_tv');
        return $this->db->get($this->table)->result_array();
    }

    public function get_beli_by_id($id)
    {
        $this->db->where('id_beli', $id);
        return $this->db->get($this->table)->row_array();
    }

    public function insert_beli($data)
    {
        return $this->db->insert($this->table, $data);
    }

    public function update_beli($id, $data)
    {
        $this->db->where('id_beli', $id);
        return $this->db->update($this->table, $data);
    }

    public function delete_beli($id)
    {
        $this->db->where('id_beli', $id);
        return $this->db->delete($this->table);
    }
}
