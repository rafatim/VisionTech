<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Produktv_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    // Ambil semua data produk TV
    public function get_all_produk_tv() {
        $query = $this->db->get('tbl_produk_tv');
        $produk_tv = $query->result_array();

        // Format ID produk
        foreach ($produk_tv as $index => $tv) {
            $produk_tv[$index]['id_tv_format'] = 'PR' . str_pad($tv['id_tv'], 3, '0', STR_PAD_LEFT);
        }

        return $produk_tv;
    }

    // Tambah produk TV
    public function tambah_produk_tv($data) {
        return $this->db->insert('tbl_produk_tv', $data);
    }

    // Ambil data produk TV berdasarkan ID
    // Di dalam model Produktv_model

public function get_harga_by_id($id_tv) {
    // Ambil harga berdasarkan id_tv
    $this->db->select('harga');
    $this->db->from('tbl_produk_tv');
    $this->db->where('id_tv', $id_tv);
    $query = $this->db->get();

    // Jika ada hasil, kembalikan harga
    if ($query->num_rows() > 0) {
        return $query->row()->harga; // Mengembalikan harga produk
    }

    // Jika tidak ada hasil, return 0 atau bisa juga return null
    return 0;
}
    // Update produk TV
    public function update_produk_tv($id, $data) {
        $this->db->where('id_tv', $id);
        return $this->db->update('tbl_produk_tv', $data);
    }

    // Hapus produk TV
    public function hapus_produk_tv($id) {
        return $this->db->delete('tbl_produk_tv', ['id_tv' => $id]);
    }
    public function get_produk_tv_by_id($id_tv) {
        // Ambil data produk berdasarkan id_tv
        $this->db->from('tbl_produk_tv');
        $this->db->where('id_tv', $id_tv);
        $query = $this->db->get();
    
        // Jika ada hasil, kembalikan data produk
        if ($query->num_rows() > 0) {
            return $query->row_array(); // Mengembalikan data produk sebagai array
        }
    
        // Jika tidak ada hasil, kembalikan null
        return null;
    }
    
}
?>
