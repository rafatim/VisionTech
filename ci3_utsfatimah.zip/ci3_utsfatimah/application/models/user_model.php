<?php
// Di dalam model Produk_model.php
class User_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    // Fungsi untuk mengambil data produk TV
    public function get_produk_tv() {
        // Contoh mengambil data produk TV dari database
        $this->db->select('*');
        $this->db->from('tbl_produktv'); // Ganti dengan nama tabel yang sesuai
        $query = $this->db->get();

        return $query->result_array(); // Mengembalikan data dalam bentuk array
    }
}
