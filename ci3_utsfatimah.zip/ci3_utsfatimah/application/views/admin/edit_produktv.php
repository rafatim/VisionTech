<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Produk TV</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <!-- Custom CSS -->
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f9f5ea; /* Cream background */
        }
        .container {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-top: 30px;
            max-width: 600px;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
    </style>
</head>
<body>


<div class="container">
    <h2 class="text-center mb-4">Edit Produk TV</h2>
    <form action="<?= site_url('Produktv/edit/'.$tv['id_tv']); ?>" method="POST">
    <div class="mb-3">
        <label for="merek" class="form-label">Merek</label>
        <input type="text" class="form-control" id="merek" name="merek" value="<?= isset($tv['merek']) ? $tv['merek'] : ''; ?>" required>
    </div>
    <div class="mb-3">
        <label for="ukuran_layar" class="form-label">Ukuran Layar</label>
        <input type="text" class="form-control" id="ukuran_layar" name="ukuran_layar" value="<?= isset($tv['ukuran_layar']) ? $tv['ukuran_layar'] : ''; ?>" required>
    </div>
    <div class="mb-3">
        <label for="resolusi" class="form-label">Resolusi</label>
        <input type="text" class="form-control" id="resolusi" name="resolusi" value="<?= isset($tv['resolusi']) ? $tv['resolusi'] : ''; ?>" required>
    </div>
    <div class="mb-3">
        <label for="tipe_layar" class="form-label">Tipe Layar</label>
        <input type="text" class="form-control" id="tipe_layar" name="tipe_layar" value="<?= isset($tv['tipe_layar']) ? $tv['tipe_layar'] : ''; ?>" required>
    </div>
    <div class="mb-3">
        <label for="harga" class="form-label">Harga</label>
        <input type="text" class="form-control" id="harga" name="harga" value="<?= isset($tv['harga']) ? $tv['harga'] : ''; ?>" required>
    </div>
    <div class="mb-3">
        <label for="stok" class="form-label">Stok</label>
        <input type="text" class="form-control" id="stok" name="stok" value="<?= isset($tv['stok']) ? $tv['stok'] : ''; ?>" required>
    </div>
    <div class="text-center">
        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
        <a href="<?= site_url('Produktv'); ?>" class="btn btn-secondary">Batal</a>
    </div>
</form>

</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYegvbE4+IoTB1PCtk9EUAnyoXHtWBs18+qogOqqAihEMEGHRwhIEhiU8Wbs" crossorigin="anonymous"></script>
</body>
</html>
