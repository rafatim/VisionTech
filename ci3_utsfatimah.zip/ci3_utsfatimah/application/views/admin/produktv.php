<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ProdukTV</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <!-- Custom CSS -->
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f9f5ea; /* Cream background */
        }
        .navbar {
            background-color: #343a40; /* Dark gray */
            color: white;
        }
        .navbar .navbar-brand {
            color: white;
            font-weight: bold;
        }
        .navbar .nav-link {
            color: white;
            transition: color 0.3s;
        }
        .navbar .nav-link:hover {
            color: #f9f5ea; 
        }
        .table th, .table td {
            vertical-align: middle;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        .alert {
            border-radius: 8px;
            margin-bottom: 20px;
        }
        /* Pastikan dropdown tampil di atas konten lainnya */
.dropdown-menu {
    position: absolute !important;
    z-index: 1000 !important;
}
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="#"><i class="bi bi-tv"></i> VisioTech</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="<?= site_url('Produktv');?>">Produk</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= site_url('Beli/transaksi_admin');?>">Transaksi</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= site_url('Auth/manage_users');?>">Data User</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link" id="profileDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false" href="<?= site_url('Auth/logout'); ?>">
                        <i class="bi bi-person-circle" ></i> Logout
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
                        <li><a class="dropdown-item text-danger" href="<?= site_url('auth/logout'); ?>">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container my-5">
    <!-- Flash Message -->
    <?php if ($this->session->flashdata('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="bi bi-check-circle"></i> <?= $this->session->flashdata('success'); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>

    <?php if ($this->session->flashdata('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="bi bi-exclamation-triangle"></i> <?= $this->session->flashdata('error'); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>

    <!-- Button and Table -->
    <a href="<?= site_url('Produktv/tambah'); ?>" class="btn btn-primary mb-3"><i class="bi bi-plus-circle"></i> Tambah Produk</a>
    <table class="table table-bordered">
        <thead class="table-dark">
            <tr>
                <th scope="col">ID Produk</th>
                <th scope="col">Merek</th>
                <th scope="col">Ukuran Layar</th>
                <th scope="col">Resolusi</th>
                <th scope="col">Tipe Layar</th>
                <th scope="col">Harga</th>
                <th scope="col">Stok</th>
                <th scope="col">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($produktv as $tv): ?>
            <tr>
                <td><?= $tv['id_tv_format']; ?></td>
                <td><?= $tv['merek']; ?></td>
                <td><?= $tv['ukuran_layar']; ?></td>
                <td><?= $tv['resolusi']; ?></td>
                <td><?= $tv['tipe_layar']; ?></td>
                <td>Rp <?= number_format($tv['harga'], 0, ',', '.'); ?></td>
                <td><?= $tv['stok']; ?></td>
                <td>
                    <a href="<?= site_url('ProdukTV/edit/'.$tv['id_tv']); ?>" class="btn btn-warning btn-sm"><i class="bi bi-pencil-square"></i></a>
                    <a href="<?= site_url('ProdukTV/hapus/'.$tv['id_tv']); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus data ini?')"><i class="bi bi-trash"></i></a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYegvbE4+IoTB1PCtk9EUAnyoXHtWBs18+qogOqqAihEMEGHRwhIEhiU8Wbs" crossorigin="anonymous"></script>
</body>
</html>
