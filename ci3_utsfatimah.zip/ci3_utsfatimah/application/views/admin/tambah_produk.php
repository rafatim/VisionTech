<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Produk</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <!-- Custom CSS -->
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f9f5ea; /* Cream background */
            color: #343a40; /* Text color */
        }
        .container {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-top: 30px;
            max-width: 600px;
        }
        h2 {
            font-weight: bold;
            margin-bottom: 20px;
            color: #343a40;
            font-size: 24px;
        }
        .btn-primary {
            background-color: #6c757d; /* Navbar-like background */
            border-color: #6c757d;
            font-weight: bold;
        }
        .btn-primary:hover {
            background-color: #5a6268; /* Slightly darker shade */
            border-color: #545b62;
        }
        .form-label {
            font-weight: 500;
        }
    </style>
</head>
<body>
<div class="container">
    <h2 class="text-center">Tambah Produk TV</h2>
    <?php if (validation_errors()): ?>
    <div class="alert alert-danger">
        <?= validation_errors(); ?>
    </div>
    <?php endif; ?>
    <form action="<?= site_url('Produktv/tambah'); ?>" method="POST">
        <div class="mb-3">
            <label for="merek" class="form-label">Merek</label>
            <input type="text" class="form-control" id="merek" name="merek">
        </div>
        <div class="mb-3">
            <label for="ukuran_layar" class="form-label">Ukuran Layar</label>
            <input type="text" class="form-control" id="ukuran_layar" name="ukuran_layar">
        </div>
        <div class="mb-3">
            <label for="resolusi" class="form-label">Resolusi</label>
            <input type="text" class="form-control" id="resolusi" name="resolusi">
        </div>
        <div class="mb-3">
            <label for="tipe_layar" class="form-label">Tipe Layar</label>
            <input type="text" class="form-control" id="tipe_layar" name="tipe_layar">
        </div>
        <div class="mb-3">
            <label for="harga" class="form-label">Harga</label>
            <input type="text" class="form-control" id="harga" name="harga">
        </div>
        <div class="mb-3">
            <label for="stok" class="form-label">Stok</label>
            <input type="text" class="form-control" id="stok" name="stok">
        </div>
        <div class="text-center">
            <button type="submit" class="btn btn-primary">Tambah Produk</button>
        </div>
    </form>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYegvbE4+IoTB1PCtk9EUAnyoXHtWBs18+qogOqqAihEMEGHRwhIEhiU8Wbs" crossorigin="anonymous"></script>
</body>
</html>
