<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaksi Pembelian</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
</head>
<style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f9f5ea; /* Cream background */
        }
        .navbar {
            background-color: #343a40; /* Dark gray */
            color: white;
        }
        .navbar .navbar-brand {
            color: white;
            font-weight: bold;
        }
        .navbar .nav-link {
            color: white;
            transition: color 0.3s;
        }
        .navbar .nav-link:hover {
            color: #f9f5ea; 
        }
        .table th, .table td {
            vertical-align: middle;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        .alert {
            border-radius: 8px;
            margin-bottom: 20px;
        }
        /* Pastikan dropdown tampil di atas konten lainnya */
.dropdown-menu {
    position: absolute !important;
    z-index: 1000 !important;
}
    </style>
<body>
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="#"><i class="bi bi-tv"></i> VisioTech</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="<?= site_url('Produktv');?>">Produk</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= site_url('Beli/transaksi_admin');?>">Transaksi</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= site_url('Auth/manage_users');?>">Data User</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link" id="profileDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false" href="<?= site_url('Auth/logout'); ?>">
                        <i class="bi bi-person-circle" ></i> Logout
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileDropdown">
                        <li><a class="dropdown-item text-danger" href="<?= site_url('auth/logout'); ?>">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

    <div class="container my-5">
        <?php if ($this->session->flashdata('success')): ?>
        <div class="alert alert-success">
            <?= $this->session->flashdata('success'); ?>
        </div>
        <?php endif; ?>

        
        <table class="table table-bordered">
            <thead class="table-dark">
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Nama</th>
                    <th scope="col">Jumlah</th>
                    <th scope="col">Alamat</th>
                    <th scope="col">Total</th>
                    <th scope="col">Produk</th>
                    <th scope="col">Aksi</th>
                </tr>
            </thead>
            <tbody>
    <?php foreach ($beli as $item): ?>  <!-- Use $beli here -->
    <tr>
        <td>TR00<?= $item['id_beli']; ?></td>
        <td><?= $item['nama']; ?></td>
        <td><?= $item['jumlah']; ?></td>
        <td><?= $item['alamat']; ?></td>
        <td>Rp <?= number_format($item['total'], 0, ',', '.'); ?></td>
        <td><?= $item['merek']; ?></td>
        <td>
            <a href="<?= site_url('Beli/hapus/'.$item['id_beli']); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus transaksi ini?')"><i class="bi bi-trash"></i></a>
        </td>
    </tr>
    <?php endforeach; ?>
</tbody>

        </table>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
