<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f9f5ea; /* Cream background */
            margin: 0;
            padding: 0;
        }
        .box-area {
            overflow: hidden;
            max-width: 600px; /* Perlebar kotak */
            width: 100%; /* Pastikan kotak mengikuti lebar layar pada viewport kecil */
        }
        .left-box {
            background: #292827; /* Dark gray */
            color: #f9f5ea; /* Cream text */
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center; /* Centers text horizontally */
            padding: 30px;
            border-top-left-radius: 10px;
            border-bottom-left-radius: 10px;
        }
        .left-box h4 {
            font-weight: 700;
            margin-bottom: 10px;
        }
        .left-box h6 {
            font-weight: 400;
            font-size: 1rem;
        }
        .box-right {
            background: #f9f5ea; /* Cream */
            padding: 30px 15px;
            border-top-right-radius: 10px;
            border-bottom-right-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .form-label {
            font-size: 0.8rem;
            color: #292827; /* Dark gray */
            font-weight: bold;
        }
        .form-control {
            font-size: 0.8rem;
            border: 1px solid #ced4da;
            border-radius: 5px;
            color: #495057; /* Dark gray */
        }
        #button {
            background-color: #292827; /* Dark gray */
            color: #f9f5ea; /* Cream text */
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            font-weight: bold;
            margin-top: 10px;
            transition: 0.3s;
        }
        #button:hover {
            background-color: #403f3e; /* Slightly lighter dark gray */
        }
        .text-end a, .text-center a {
            font-size: 0.8rem;
        }
        .toast {
            position: fixed; /* Use fixed positioning to position the toast on top */
            top: 10px; /* Adjust the top space to be closer to the top of the viewport */
            left: 50%; /* Center the toast horizontally */
            transform: translateX(-50%); /* Adjust horizontal centering */
            z-index: 1050; /* Ensure it appears on top of other elements */
            width: auto; /* Let the toast adjust based on content width */
        }

    </style>
</head>
<body>
    <!-- Toast -->
    <div class="toast align-items-center" role="alert" aria-live="assertive" aria-atomic="true" id="myToast">
        <div class="d-flex">
            <div class="toast-body">
                <p><?= $this->session->flashdata('message_pw') ?></p>
            </div>
            <button type="button" class="btn-close me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var message = "<?= $this->session->flashdata('message_pw') ?>";
            if (message) {
                var toastEl = document.getElementById('myToast');
                var toast = new bootstrap.Toast(toastEl);
                toast.show();
            }
        });
    </script>

    <div class="container d-flex justify-content-center align-items-center min-vh-100">
        <div class="row box-area shadow-lg">
            <div class="col-lg-5 left-box">
                <h4>Log-In</h4>
                <h6><i class="bi bi-tv"></i> VisionTech</h6>
            </div>
            <div class="col-lg-7 box-right">
                
                <form action="<?= site_url('Auth'); ?>" method="POST">
                    <div class="mb-3">
                        <label for="email" class="form-label">Email:</label>
                        <input type="text" class="form-control" name="email" id="email" placeholder="">
                        <!-- Pesan error untuk email -->
                        <?= form_error('email', '<small class="text-danger">', '</small>'); ?>
                        <!-- Pesan flash untuk email tidak terdaftar -->
                        <small class="text-danger"><?= $this->session->flashdata('message_email'); ?></small>
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label">Password:</label>
                        <input type="password" class="form-control" name="password" id="password" placeholder="">
                        <!-- Pesan error untuk password -->
                        <?= form_error('password', '<small class="text-danger">', '</small>'); ?>

                        <!-- Pesan flash untuk password salah -->
                        <small class="text-danger"><?= $this->session->flashdata('message_password'); ?></small>
                    </div>

                    <div class="d-flex justify-content-between align-items-center">
                        <div class="text-end">
                            <a href="<?= site_url('auth/forgot_password');?>">Forgot password?</a>
                        </div>
                    </div>

                    <button type="submit" id="button" class="btn w-100 mt-3" name="login">Log In</button>

                    <div class="mt-3 text-center">
                        <p>Don't have an account? <a href="<?= site_url('auth/regis'); ?>">Sign Up</a></p>
                    </div>
                </form>

            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>
