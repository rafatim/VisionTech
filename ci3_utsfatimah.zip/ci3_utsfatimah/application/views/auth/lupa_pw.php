<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lupa Password</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f9f5ea; /* Cream background */
            margin: 0;
            padding: 0;
        }
        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .box-area {
            max-width: 400px;
            width: 100%;
            background-color: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .box-area h5 {
            text-align: center;
            margin-bottom: 20px;
        }
        .box-area form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        .box-area input {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }
        #button {
            background-color: #292827; /* Dark gray */
            color: #f9f5ea; /* Cream text */
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            font-weight: bold;
            margin-top: 10px;
            transition: 0.3s;
        }
        #button:hover {
            background-color: #403f3e; /* Slightly lighter dark gray */
        }
        .box-area a {
            display: block;
            text-align: center;
            margin-top: 15px;
            color: #007bff;
            text-decoration: none;
        }
        .message, .error {
            text-align: center;
            font-size: 14px;
        }
        .message {
            color: #28a745;
        }
        .error {
            color: #dc3545;
        }
        .back-link {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 10px;
            font-size: 16px;
        }
        .back-link i {
            margin-right: 8px;
            font-size: 18px; /* Adjust icon size to match the text */
            margin-top: 18px;
        }
    </style>
</head>
<body>

    <div class="container">
        <div class="box-area shadow-lg">
            <h5 class="card-title">Lupa Password</h5>
            
            <!-- Flash Messages -->
                <p class="error"><?= $this->session->flashdata('error') ?></p>
            <!-- Forgot Password Form -->
            <form method="POST" action="<?= site_url('auth/process_forgot_password') ?>">
                <input type="email" name="email" id="email" placeholder="Masukkan email Anda" required>
                <button id="button" type="submit">Kirim</button>
            </form>

            <!-- Back to Login -->
            <div class="back-link">
                <i class="bi bi-arrow-left-circle"></i><a href="<?= site_url('auth') ?>">Kembali ke Login</a>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>
