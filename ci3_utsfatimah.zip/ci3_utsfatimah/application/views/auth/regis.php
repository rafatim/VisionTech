<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f9f5ea; /* Cream background */
            margin: 0;
            padding: 0;
        }
        .box-area {
            overflow: hidden;
            max-width: 600px; /* Perlebar kotak */
            width: 100%; /* Pastikan kotak mengikuti lebar layar pada viewport kecil */
        }
        .box-right {
            background: #292827; /* Dark gray */
            color: #f9f5ea; /* Cream text */
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center; /* Centers text horizontally */
            padding: 30px;
            border-top-right-radius: 10px;
            border-bottom-right-radius: 10px;
        }
        .left-box h4 {
            font-weight: 700;
            margin-bottom: 10px;
        }
        .left-box h6 {
            font-weight: 400;
            font-size: 1rem;
        }
        .box-left {
            background: #f9f5ea; /* Cream */
            padding: 30px 15px;
            border-top-left-radius: 10px;
            border-bottom-left-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .form-label {
            font-size: 0.8rem;
            color: #292827; /* Dark gray */
            font-weight: bold;
        }
        .form-control {
            font-size: 0.8rem;
            border: 1px solid #ced4da;
            border-radius: 5px;
            color: #495057; /* Dark gray */
        }
        #button {
            background-color: #292827; /* Dark gray */
            color: #f9f5ea; /* Cream text */
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            font-weight: bold;
            margin-top: 10px;
            transition: 0.3s;
        }
        #button:hover {
            background-color: #403f3e; /* Slightly lighter dark gray */
        }
        .text-end a, .text-center a {
            font-size: 0.8rem;
        }
    </style>
</head>
<body>
    <div class="container d-flex justify-content-center align-items-center min-vh-100">
        <div class="row box-area shadow-lg">
            <div class="col-lg-7 box-left">
                <form action="<?= site_url('Auth/regis');?>" method="POST">
                <small class="text-danger"><?= $this->session->flashdata('message_regis'); ?></small>
                    <div class="mb-3">
                        <label for="username" class="form-label">Nama Lengkap:</label>
                        <input type="text" class="form-control" name="user" id="user" value="<?= set_value('user');?>">
                        <?= form_error('user', '<small class="text-danger pl-3">', '</small>');?>
                    </div>
                    <div class="mb-3">
                        <label for="username" class="form-label">Status:</label>
                        <input type="text" class="form-control" name="status" id="status" value="<?= set_value('status');?>">
                        <?= form_error('status', '<small class="text-danger pl-3">', '</small>');?>
                    </div>
                    <div class="mb-3">
                        <label for="username" class="form-label">Email:</label>
                        <input type="text" class="form-control" name="email" id="email" value="<?= set_value('email');?>">
                        <?= form_error('email', '<small class="text-danger pl-3">', '</small>');?>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password:</label>
                        <input type="password" class="form-control" name="password" id="password">
                        <?= form_error('password', '<small class="text-danger pl-3">', '</small>');?>
                    </div>
                    <button type="submit" id="button" class="btn w-100 mt-3" name="signup">Sign Up</button>
                    <div class="mt-3 text-center">
                        <p id="p">Already have an account? <a href="<?= site_url('auth/index');?>">Sign In</a></p>
                    </div>
                </form>
            </div>
            <div class="col-lg-5 box-right">
                <h4>Sign-Up</h4>
                <h6><i class="bi bi-tv"></i> VisionTech</h6>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>
