<?php
// Ambil ID produk dari URL
$id_produk_terpilih = isset($_GET['id_tv']) ? $_GET['id_tv'] : null;

// Ambil detail produk berdasarkan ID
$produk_terpilih = null;
if ($id_produk_terpilih) {
    foreach ($produk as $p) {
        if ($p['id_tv'] == $id_produk_terpilih) {
            $produk_terpilih = $p;
            break;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Transaksi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f9f5ea;
            color: #343a40;
        }
        .container {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-top: 30px;
            max-width: 600px;
        }
        .btn-success {
            background-color: #6c757d;
            border-color: #6c757d;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container my-5">
        <h2>Tambah Transaksi Pembelian</h2>
        <form action="<?= site_url('Beli/tambah'); ?>" method="POST">
            <div class="mb-3">
                <label for="nama" class="form-label">Nama Pembeli</label>
                <input type="text" class="form-control" id="nama" name="nama" required>
            </div>
            <div class="mb-3">
                <label for="jumlah" class="form-label">Jumlah</label>
                <input type="number" class="form-control" id="jumlah" name="jumlah" required>
            </div>
            <div class="mb-3">
                <label for="alamat" class="form-label">Alamat</label>
                <textarea class="form-control" id="alamat" name="alamat" rows="3" required></textarea>
            </div>
            <div class="mb-3">
                <label for="id_tv" class="form-label">Produk</label>
                <select class="form-select" id="id_tv" name="id_tv" required>
                    <?php foreach ($produk as $p): ?>
                        <option value="<?= $p['id_tv']; ?>" <?= $id_produk_terpilih == $p['id_tv'] ? 'selected' : ''; ?>>
                            <?= $p['merek']; ?> - Rp <?= number_format($p['harga'], 0, ',', '.'); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php if ($produk_terpilih): ?>
                <p><strong>Produk Terpilih:</strong> <?= $produk_terpilih['merek']; ?> - Rp <?= number_format($produk_terpilih['harga'], 0, ',', '.'); ?></p>
            <?php endif; ?>
            <button type="submit" class="btn btn-success">Simpan Transaksi</button>
        </form>
    </div>
</body>
</html>
