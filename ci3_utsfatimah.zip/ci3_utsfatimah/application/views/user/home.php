<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Pengguna</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f9f5ea; /* Cream background */
        }

        .navbar {
            background-color: #343a40;
            color: white;
        }

        .navbar .navbar-brand {
            color: white;
            font-weight: bold;
        }

        .navbar .nav-link {
            color: white;
            transition: color 0.3s;
        }

        .navbar .nav-link:hover {
            color: #f9f5ea;
        }

        .carousel-item img {
            object-fit: cover;
            height: 400px;
        }

        .carousel-inner {
            border-radius: 10px;
            overflow: hidden;
        }

        .container {
            margin-top: 30px;
        }

        .card {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        .card img {
            height: 200px;
            object-fit: cover;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
        }

        .card-body {
            padding: 15px;
        }

        .btn-primary {
            background-color: #343a40;
            border: none;
        }

        .btn-primary:hover {
            background-color: #f9f5ea;
            color: #343a40;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#"><i class="bi bi-tv"></i> VisioTech</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <div class="navbar-nav ms-auto">
                    <a class="nav-link" id="profileDropdown" role="button" data-bs-toggle="dropdown"
                        aria-expanded="false" href="<?= site_url('Auth/logout'); ?>">
                        <i class="bi bi-person-circle"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Carousel -->
    <div class="container mt-4">
        <div id="carouselExampleAutoplaying" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="<?= base_url('assets/img/tv2.jpg'); ?>" class="d-block w-100" alt="TV Image 1">
                </div>
                <div class="carousel-item">
                    <img src="<?= base_url('assets/img/tv3.jpg'); ?>" class="d-block w-100" alt="TV Image 2">
                </div>
                <div class="carousel-item">
                    <img src="<?= base_url('assets/img/tv4.png'); ?>" class="d-block w-100" alt="TV Image 3">
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying"
                data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying"
                data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </div>

    <?php if ($this->session->flashdata('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="bi bi-check-circle"></i> <?= $this->session->flashdata('success'); ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>
    <!-- Produk TV -->
    <div class="container mt-5">
        <div class="row">
            <?php foreach ($produk_tv as $tv): ?>
            <div class="col-md-4 mb-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><?= $tv['merek']; ?> - <?= $tv['ukuran_layar']; ?></h5>
                        <p class="card-text">Resolusi: <?= $tv['resolusi']; ?></p>
                        <p class="card-text">Tipe Layar: <?= $tv['tipe_layar']; ?></p>
                        <p class="card-text">Harga: <?= 'Rp ' . number_format($tv['harga'], 0, ',', '.'); ?></p>
                        <a href="<?= site_url('Beli?id_tv=' . $tv['id_tv']); ?>" class="btn btn-primary">Beli</a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYegvbE4+IoTB1PCtk9EUAnyoXHtWBs18+qogOqqAihEMEGHRwhIEhiU8Wbs" crossorigin="anonymous">
    </script>
</body>

</html>
